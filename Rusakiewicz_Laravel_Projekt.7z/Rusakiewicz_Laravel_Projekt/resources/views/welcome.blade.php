<x-app-layout>
    Test
</x-app-layout>
