export const PRODUCTS_PER_PAGE = 10
export const USERS_PER_PAGE = 10
export const CUSTOMERS_PER_PAGE = 10
